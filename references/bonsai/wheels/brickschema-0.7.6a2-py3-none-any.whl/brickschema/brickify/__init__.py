"""
The subpackage `brickify` provides a set of handlers and a CLI tool
for converting tabular or graph-based building data to Brick models.
"""
