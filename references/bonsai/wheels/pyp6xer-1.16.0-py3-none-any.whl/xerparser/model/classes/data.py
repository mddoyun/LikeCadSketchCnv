

class Data:

    def __init__(self) -> None:
        self.projects = None
        self.wbss = None
        self.tasks = None
        self.resources = None
        self.taskresource = None
        self.taskactvcodes = None
        self.predecessors = None