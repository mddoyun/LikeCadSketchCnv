# Contributors

**Ashley Sommer**
* almost everything!

**Nicholas Car**
* a few small admin bits and pieces

**Jonathan Yu**
* pyinstaller spec for compiling pySHACL cli as a Windows binary

