"""BCF XML v3 handler."""
